from django.apps import AppConfig


class AhtishamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Ahtisham'
